import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'format.dart';
import 'models.dart';
import 'reminders.dart';

const kSorts = {
  'updated': 'Last edited',
  'created': 'Newest first',
  'reminder': 'Reminder time',
  'color': 'Color',
};

/// Holds all notes, saves them on the phone and keeps notifications in step.
class NoteStore extends ChangeNotifier {
  final List<Note> notes = [];
  final theme = ValueNotifier<ThemeMode>(ThemeMode.system);
  String sort = 'updated';
  bool examplesDismissed = false;

  SharedPreferences? _prefs;
  Timer? _saveTimer;
  final Map<String, Timer> _syncTimers = {};

  Future<void> load() async {
    try {
      _prefs = await SharedPreferences.getInstance();
    } catch (_) {}
    final raw = _prefs?.getString('notes_v1');
    if (raw == null) {
      notes.addAll(_seed());
    } else {
      try {
        final list = jsonDecode(raw) as List;
        notes.addAll(list.map((e) => Note.fromJson(Map<String, dynamic>.from(e as Map))));
      } catch (_) {}
    }
    final t = _prefs?.getInt('theme') ?? 0;
    theme.value = ThemeMode.values[(t >= 0 && t < ThemeMode.values.length) ? t : 0];
    sort = _prefs?.getString('sort') ?? 'updated';
    examplesDismissed = _prefs?.getBool('examplesDismissed') ?? false;

    // Trash keeps notes for 30 days.
    final now = DateTime.now();
    notes.removeWhere((n) => n.trashedAt != null && now.difference(n.trashedAt!).inDays >= 30);
    rollRepeats(notify: false);
    _saveNow();
    for (final n in notes) {
      Reminders.sync(n);
    }
  }

  // ---------- saving ----------
  void _scheduleSave() {
    _saveTimer?.cancel();
    _saveTimer = Timer(const Duration(milliseconds: 400), _saveNow);
  }

  void _saveNow() {
    _prefs?.setString('notes_v1', jsonEncode(notes.map((n) => n.toJson()).toList()));
  }

  void flush() {
    _saveTimer?.cancel();
    _saveNow();
  }

  void _sync(Note n, {bool now = false}) {
    _syncTimers.remove(n.id)?.cancel();
    if (now) {
      Reminders.sync(n);
      return;
    }
    _syncTimers[n.id] = Timer(const Duration(milliseconds: 800), () {
      _syncTimers.remove(n.id);
      Reminders.sync(n);
    });
  }

  /// Call after any edit to a note.
  void changed(Note n, {bool reminder = false}) {
    n.updated = DateTime.now();
    n.example = false;
    notifyListeners();
    _scheduleSave();
    _sync(n, now: reminder);
    if (reminder && n.reminder != null) Reminders.requestPermission();
  }

  // ---------- queries ----------
  Note? byId(String id) {
    for (final n in notes) {
      if (n.id == id) return n;
    }
    return null;
  }

  /// view: 0 notes, 1 reminders, 2 archive, 3 trash
  bool inView(Note n, int view) => switch (view) {
        3 => n.trashedAt != null,
        2 => n.trashedAt == null && n.archived,
        1 => n.active && n.reminder != null,
        _ => n.active,
      };

  int count(int view) => notes.where((n) => inView(n, view)).length;

  List<Note> visible(int view, String? label, String query) {
    Iterable<Note> list = notes.where((n) => inView(n, view));
    if (label != null) list = list.where((n) => n.label == label);
    final q = query.trim().toLowerCase();
    if (q.isNotEmpty) list = list.where((n) => n.searchText.contains(q));
    final out = list.toList();
    final s = view == 1 ? 'reminder' : sort;
    int far(Note n) => n.reminder?.millisecondsSinceEpoch ?? 1 << 52;
    out.sort((a, b) => switch (s) {
          'created' => b.created.compareTo(a.created),
          'reminder' => far(a).compareTo(far(b)),
          'color' => a.color != b.color ? a.color.compareTo(b.color) : b.updated.compareTo(a.updated),
          _ => b.updated.compareTo(a.updated),
        });
    return out;
  }

  /// Reminders that went off in the last hour and haven't shown their big alert yet.
  List<Note> dueForAlert() {
    final now = DateTime.now();
    return notes.where((n) {
      final r = n.reminder;
      return r != null &&
          n.active &&
          !n.example &&
          !r.isAfter(now) &&
          now.difference(r).inMinutes < 60 &&
          n.shownFor != r;
    }).toList()
      ..sort((a, b) => a.reminder!.compareTo(b.reminder!));
  }

  void markShown(Note n) {
    n.shownFor = n.reminder;
    _scheduleSave();
  }

  List<Note> overdue() =>
      notes.where((n) => n.overdue).toList()..sort((a, b) => a.reminder!.compareTo(b.reminder!));

  // ---------- actions ----------
  Note create({String title = '', bool isList = false, DateTime? reminder, int color = 0, String? label}) {
    final n = Note(title: title, isList: isList, reminder: reminder, color: color, label: label);
    notes.insert(0, n);
    changed(n, reminder: reminder != null);
    return n;
  }

  void toggleItem(Note n, CheckItem it) {
    it.done = !it.done;
    changed(n);
  }

  void setReminder(Note n, DateTime? when) {
    n.reminder = when;
    if (when == null) {
      n.repeat = Repeat.none;
      Reminders.cancelSnooze(n);
    }
    changed(n, reminder: true);
  }

  void setRepeat(Note n, Repeat r) {
    n.repeat = r;
    if (r != Repeat.none) n.reminder = nextRepeat(n.reminder ?? atDay(1, 9), r);
    changed(n, reminder: true);
  }

  /// [d] null means tomorrow at 9 AM.
  void snooze(Note n, Duration? d) {
    final when = d == null ? atDay(1, 9) : DateTime.now().add(d);
    if (n.repeat != Repeat.none) {
      Reminders.scheduleOnce(n, when);
      notifyListeners();
      return;
    }
    setReminder(n, when);
  }

  /// Marks a reminder done. Repeating reminders move to their next time.
  String complete(Note n) {
    Reminders.cancelSnooze(n);
    if (n.repeat != Repeat.none && n.reminder != null) {
      n.reminder = nextRepeat(n.reminder!, n.repeat);
      changed(n, reminder: true);
      return 'Next reminder ${fmtWhen(n.reminder!)}';
    }
    n.reminder = null;
    changed(n, reminder: true);
    return 'Reminder done';
  }

  void rollRepeats({bool notify = true}) {
    final now = DateTime.now();
    var any = false;
    for (final n in notes) {
      if (n.repeat != Repeat.none && n.reminder != null && !n.reminder!.isAfter(now)) {
        n.reminder = nextRepeat(n.reminder!, n.repeat);
        any = true;
      }
    }
    if (any && notify) {
      notifyListeners();
      _scheduleSave();
    }
  }

  void togglePin(Note n) {
    n.pinned = !n.pinned;
    changed(n);
  }

  void toggleArchive(Note n) {
    n.archived = !n.archived;
    if (n.archived) n.pinned = false;
    changed(n, reminder: true);
  }

  void trash(Note n) {
    n.trashedAt = DateTime.now();
    n.pinned = false;
    changed(n, reminder: true);
  }

  void restore(Note n) {
    n.trashedAt = null;
    changed(n, reminder: true);
  }

  void deleteForever(Note n) {
    Reminders.cancel(n);
    notes.remove(n);
    notifyListeners();
    _scheduleSave();
  }

  void emptyTrash() {
    for (final n in notes.where((n) => n.trashedAt != null).toList()) {
      Reminders.cancel(n);
      notes.remove(n);
    }
    notifyListeners();
    _scheduleSave();
  }

  void removeIfEmpty(String id) {
    final n = byId(id);
    if (n != null && n.isEmpty) deleteForever(n);
  }

  void removeExamples() {
    for (final n in notes.where((n) => n.example).toList()) {
      Reminders.cancel(n);
      notes.remove(n);
    }
    notifyListeners();
    _scheduleSave();
  }

  void keepExamples() {
    examplesDismissed = true;
    _prefs?.setBool('examplesDismissed', true);
    for (final n in notes.where((n) => n.example)) {
      n.example = false;
      Reminders.sync(n);
    }
    notifyListeners();
    _scheduleSave();
  }

  void setTheme(ThemeMode m) {
    theme.value = m;
    _prefs?.setInt('theme', m.index);
  }

  void setSort(String s) {
    sort = s;
    _prefs?.setString('sort', s);
    notifyListeners();
  }

  // ---------- first-run examples ----------
  List<Note> _seed() {
    final now = DateTime.now();
    DateTime ago(int i) => now.subtract(Duration(minutes: 37 * i));
    return [
      Note(
          title: 'Pay electricity bill',
          body: 'Due today. Pay in the app and keep the receipt screenshot.',
          color: 3,
          label: 'Personal',
          reminder: now.subtract(const Duration(minutes: 25)),
          example: true,
          updated: ago(0)),
      Note(
          title: 'Groceries',
          isList: true,
          items: [
            CheckItem(text: 'Milk', done: true),
            CheckItem(text: 'Atta 5 kg'),
            CheckItem(text: 'Tomatoes'),
            CheckItem(text: 'Curd'),
            CheckItem(text: 'Bananas', done: true),
          ],
          color: 1,
          label: 'Shopping',
          pinned: true,
          example: true,
          updated: ago(1)),
      Note(
          title: 'Marketing case study',
          body: 'Read the case before class. Note 3 key decisions and the numbers behind them.',
          color: 2,
          label: 'College',
          reminder: atDay(1, 9),
          example: true,
          updated: ago(2)),
      Note(
          title: 'Where I parked',
          body: 'Mall basement B2, pillar 14, near the lift.',
          color: 0,
          label: 'Memory',
          example: true,
          updated: ago(3)),
      Note(
          title: 'Morning gym',
          body: 'Leg day. Carry water bottle.',
          color: 5,
          label: 'Personal',
          reminder: atDay(1, 7),
          repeat: Repeat.daily,
          example: true,
          updated: ago(4)),
      Note(
          title: 'Project ideas',
          isList: true,
          items: [
            CheckItem(text: 'Sticky notes app', done: true),
            CheckItem(text: 'Expense splitter for hostel'),
            CheckItem(text: 'Habit tracker'),
          ],
          color: 4,
          label: 'Work',
          example: true,
          updated: ago(5)),
    ];
  }
}
