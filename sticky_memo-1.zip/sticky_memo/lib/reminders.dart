import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:timezone/data/latest_all.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;

import 'models.dart';

typedef NotificationHandler = void Function(String noteId, String? actionId);

/// Schedules real Android notifications, so reminders ring even when the app is closed.
class Reminders {
  Reminders._();

  static final plugin = FlutterLocalNotificationsPlugin();
  static NotificationHandler? onResponse;
  static NotificationResponse? launchResponse;

  static Future<void> init() async {
    tzdata.initializeTimeZones();
    try {
      final name = await FlutterTimezone.getLocalTimezone();
      tz.setLocalLocation(tz.getLocation(name));
    } catch (_) {
      try {
        tz.setLocalLocation(tz.getLocation('Asia/Kolkata'));
      } catch (_) {}
    }
    await plugin.initialize(
      const InitializationSettings(
        android: AndroidInitializationSettings('@mipmap/ic_launcher'),
      ),
      onDidReceiveNotificationResponse: (r) {
        final id = r.payload;
        if (id != null) onResponse?.call(id, r.actionId);
      },
    );
    final details = await plugin.getNotificationAppLaunchDetails();
    if (details != null && details.didNotificationLaunchApp) {
      launchResponse = details.notificationResponse;
    }
  }

  static AndroidFlutterLocalNotificationsPlugin? get _android =>
      plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();

  static Future<void> requestPermission() async {
    try {
      await _android?.requestNotificationsPermission();
    } catch (_) {}
  }

  static final NotificationDetails _details = NotificationDetails(
    android: AndroidNotificationDetails(
      'reminders',
      'Reminders',
      channelDescription: 'Reminders for your notes',
      importance: Importance.max,
      priority: Priority.high,
      // Opens the app over the lock screen so the half-screen reminder appears.
      fullScreenIntent: true,
      actions: <AndroidNotificationAction>[
        AndroidNotificationAction('snooze', 'Snooze 10 min', showsUserInterface: true),
        AndroidNotificationAction('done', 'Done', showsUserInterface: true),
      ],
    ),
  );

  static String _body(Note n) {
    if (n.isList) {
      final left = n.items.where((i) => !i.done && i.text.trim().isNotEmpty).length;
      return left == 0 ? 'Checklist' : '$left item${left == 1 ? '' : 's'} left';
    }
    final b = n.body.trim();
    if (b.isEmpty || b == n.displayTitle) return 'Reminder';
    return b;
  }

  static Future<void> _schedule(int id, Note n, DateTime when, DateTimeComponents? comps) async {
    final at = tz.TZDateTime.from(when, tz.local);
    Future<void> go(AndroidScheduleMode mode) => plugin.zonedSchedule(
          id,
          n.displayTitle,
          _body(n),
          at,
          _details,
          androidScheduleMode: mode,
          uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
          matchDateTimeComponents: comps,
          payload: n.id,
        );
    try {
      await go(AndroidScheduleMode.exactAllowWhileIdle);
    } on PlatformException {
      // Exact alarms not allowed on this phone: fall back to a slightly less precise alarm.
      try {
        await go(AndroidScheduleMode.inexactAllowWhileIdle);
      } catch (_) {}
    } catch (_) {}
  }

  /// Cancels and re-creates the notification for a note.
  static Future<void> sync(Note n) async {
    try {
      await plugin.cancel(n.nid);
    } catch (_) {}
    final r = n.reminder;
    if (r == null || !n.active || n.example) return;
    if (n.repeat == Repeat.none && !r.isAfter(DateTime.now())) return;
    final comps = switch (n.repeat) {
      Repeat.daily => DateTimeComponents.time,
      Repeat.weekly => DateTimeComponents.dayOfWeekAndTime,
      Repeat.monthly => DateTimeComponents.dayOfMonthAndTime,
      Repeat.none => null,
    };
    await _schedule(n.nid, n, r, comps);
  }

  /// A one-off extra notification (used to snooze a repeating reminder).
  static Future<void> scheduleOnce(Note n, DateTime when) async {
    try {
      await plugin.cancel(n.nid + 1);
    } catch (_) {}
    await _schedule(n.nid + 1, n, when, null);
  }

  static Future<void> cancelSnooze(Note n) async {
    try {
      await plugin.cancel(n.nid + 1);
    } catch (_) {}
  }

  static Future<void> cancel(Note n) async {
    try {
      await plugin.cancel(n.nid);
      await plugin.cancel(n.nid + 1);
    } catch (_) {}
  }
}
